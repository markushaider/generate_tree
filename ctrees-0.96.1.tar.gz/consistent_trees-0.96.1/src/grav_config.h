#ifndef _GRAV_CONFIG_H_
#define _GRAV_CONFIG_H_

void grav_config(char *filename, int write_cfile);

#endif /* _GRAV_CONFIG_H_ */

