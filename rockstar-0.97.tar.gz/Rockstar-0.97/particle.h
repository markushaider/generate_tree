#ifndef PARTICLE_H
#define PARTICLE_H

#include <stdint.h>

struct particle {
  int64_t id;
  float pos[6];
};

#endif
