#ifndef _MAIN_H_
#define _MAIN_H_

void do_single(int argc, char **argv);

#endif /* _MAIN_H_ */
