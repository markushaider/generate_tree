#ifndef _NFW_H_
#define _NFW_H_

float calc_scale_radius(float mvir, float rvir, float vmax, float rvmax, float scale);

#endif /* _NFW_H_ */
