#ifndef _VERSION_H_
#define _VERSION_H_

#define ROCKSTAR_VERSION "0.97.5 (Beta)"

#endif /* _VERSION_H_ */
