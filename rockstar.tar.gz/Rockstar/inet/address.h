#ifndef _ADDRESS_H_
#define _ADDRESS_H_

char *get_interface_address(char *ifname);

#endif /* _ADDRESS_H_ */
