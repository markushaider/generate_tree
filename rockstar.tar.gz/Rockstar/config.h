#ifndef _CONFIG_H_
#define _CONFIG_H_

void setup_config(void);
void do_config(char *filename);
void output_config(char *filename);

#endif /* _CONFIG_H_ */
