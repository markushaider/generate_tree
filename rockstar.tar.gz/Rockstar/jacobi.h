#ifndef _JACOBI_H_
#define _JACOBI_H_

void calc_deviations(double corr[][6], double *sig_x, double *sig_v);

#endif /* _JACOBI_H_ */
